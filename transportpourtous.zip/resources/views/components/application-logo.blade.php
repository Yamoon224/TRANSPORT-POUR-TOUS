<img src="{{ asset(ispublicpath() .'/logo/transportpourtous.webp') }}" alt="" height="80" width="80">
