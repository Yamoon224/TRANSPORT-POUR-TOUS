<footer id="footer">
    <div class="show-fixed pad-rgt pull-right">
        You have <a href="#" class="text-main"><span class="badge badge-danger">3</span> pending action.</a>
    </div>    
    
    <p class="text-center">{{ config('app.name', 'SURVIVOR-NETWORK') }} &#0169; {{ date('Y') }}</p>
</footer>