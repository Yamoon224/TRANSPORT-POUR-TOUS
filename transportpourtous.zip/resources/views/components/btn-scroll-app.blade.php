<button class="scroll-top btn">
    <i class="pci-chevron chevron-up"></i>
</button>