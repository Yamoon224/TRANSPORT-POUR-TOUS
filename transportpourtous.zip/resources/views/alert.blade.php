<div class="alert alert-mint">
    <!--<button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>-->
    <strong>{{ $title }}</strong> {{ $message }}.
</div>