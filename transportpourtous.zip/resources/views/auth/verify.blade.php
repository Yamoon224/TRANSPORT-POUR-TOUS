<div class="panel">
    <div class="panel-body text-center">
        <i class="img-md img-circle mar-btm demo-psi-mail-send icon-3x icon-fw"></i>
        <p class="text-lg text-semibold mar-no text-main">Sign Up successful</p>
        <p class="text-sm">An verification message was sent to your email address</p>
    </div>
</div>